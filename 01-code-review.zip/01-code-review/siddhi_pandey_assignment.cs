// =============================================================================
// siddhi_pandey_assignment.cs
// Fixed version of LoginTests — Playwright C# / NUnit E2E test suite
//
// SUMMARY OF ALL FIXES APPLIED (14 issues addressed):
//   FIX-01  Wrong file extension (.css → .cs)
//   FIX-02  Removed Thread.Sleep — blocks thread pool; wrong in async tests
//   FIX-03  Removed arbitrary Task.Delay — replaced with Playwright auto-waits
//   FIX-04  Replaced broad "button" locator with "button[type='submit']"
//   FIX-05  Replaced broad "a" locator with "a[href*='forgot-password']"
//   FIX-06  Removed silent catch block — test now fails properly on error
//   FIX-07  Added URL assertion after failed login (must stay on /login)
//   FIX-08  Credentials moved to environment variables (no secrets in source)
//   FIX-09  Removed re-hardcoded credentials inside UserCanLogout
//   FIX-10  Replaced all hardcoded URLs with baseUrl field (consistent)
//   FIX-11  Added [SetUp] — removed duplicated navigation code from every test
//   FIX-12  Replaced single-char variable names (e,p,b) with descriptive names
//   FIX-13  Modernised assertions to Assert.That(...) style (NUnit 3+)
//   FIX-14  SqlInjection test now also verifies an error message is visible
// =============================================================================

using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;
using NUnit.Framework;

namespace EcommerceTests
{
    [TestFixture]
    [Category("Login")]       // Organise tests so they can be filtered by category
    public class siddhi_pandey_assignment : PageTest
    {
        // -------------------------------------------------------------------------
        // FIX-08 & FIX-10: Read sensitive values from environment variables so that
        // credentials never appear in source code (OWASP A02 — Cryptographic Failures).
        // Fallback defaults are acceptable only for local developer machines; in CI/CD
        // the environment variables must always be set.
        // -------------------------------------------------------------------------
        private readonly string baseUrl  = Environment.GetEnvironmentVariable("BASE_URL")       ?? "https://example-shop.com";
        private readonly string email    = Environment.GetEnvironmentVariable("TEST_EMAIL")     ?? "test@example.com";
        private readonly string password = Environment.GetEnvironmentVariable("TEST_PASSWORD")  ?? "Password123!";

        // -------------------------------------------------------------------------
        // FIX-11: [SetUp] runs before every test.
        // All tests started with the exact same "navigate + wait" block — extract it
        // here once so we never duplicate code and changes apply everywhere at once.
        //
        // FIX-02 & FIX-03: Replaced Thread.Sleep / Task.Delay with
        // WaitForLoadStateAsync(NetworkIdle).  Playwright's auto-waiting is both
        // faster and more reliable than fixed timers — it waits exactly as long as
        // needed instead of a worst-case hard-coded number of seconds.
        // -------------------------------------------------------------------------
        [SetUp]
        public async Task NavigateToLoginPage()
        {
            await Page.GotoAsync(baseUrl + "/login");
            await Page.WaitForLoadStateAsync(LoadState.NetworkIdle);
        }

        // =========================================================================
        // TEST 1 — Happy path: valid credentials
        // =========================================================================
        [Test]
        public async Task UserCanLoginWithValidCredentials()
        {
            await Page.Locator("#email").FillAsync(email);
            await Page.Locator("#password").FillAsync(password);

            // FIX-04: "button[type='submit']" targets the login submit button only.
            //         Page.Locator("button") is too broad — it could click any button
            //         on the page (e.g. a "Show password" toggle).
            await Page.Locator("button[type='submit']").ClickAsync();

            // FIX-03: WaitForURLAsync blocks until the browser URL changes to the
            //         expected value, replacing two arbitrary sleep calls.
            await Page.WaitForURLAsync(baseUrl + "/dashboard");

            // FIX-13: Assert.That(...) is the modern, fluent NUnit 3 assertion style.
            //         Assert.AreEqual / Assert.IsTrue are deprecated legacy methods.
            Assert.That(Page.Url, Is.EqualTo(baseUrl + "/dashboard"),
                "After a successful login the user should be redirected to /dashboard.");

            var userName = await Page.Locator(".user-name").TextContentAsync();
            Assert.That(userName, Is.EqualTo("Test User"),
                "The dashboard should display the logged-in user's name.");
        }

        // =========================================================================
        // TEST 2 — Negative path: wrong password
        // =========================================================================
        [Test]
        public async Task LoginFailsWithInvalidPassword()
        {
            // FIX-12: Use descriptive variable names (emailLocator, not 'e').
            //         Single-character names make code hard to read and review.
            var emailLocator    = Page.Locator("#email");
            var passwordLocator = Page.Locator("#password");
            var submitButton    = Page.Locator("button[type='submit']");   // FIX-04

            await emailLocator.FillAsync(email);
            await passwordLocator.FillAsync("wrongpassword");
            await submitButton.ClickAsync();

            // FIX-06: The original code wrapped the assertion in try/catch and only
            //         printed the exception — the test passed silently even on error.
            //         Now we let Playwright throw naturally, failing the test properly.
            //
            // FIX-03: WaitForAsync() waits until the element appears in the DOM,
            //         replacing the arbitrary Thread.Sleep + Task.Delay pair.
            var errorLocator = Page.Locator(".error-message");
            await errorLocator.WaitForAsync();

            var errorText = await errorLocator.TextContentAsync();
            Assert.That(errorText, Does.Contain("Invalid"),
                "An 'Invalid credentials' error message should appear on failed login.");

            // FIX-07: Also assert the user is still on the login page.
            //         The original test never checked this — a redirect to /dashboard
            //         would have gone unnoticed.
            Assert.That(Page.Url, Is.EqualTo(baseUrl + "/login"),
                "After a failed login the URL must remain on /login.");
        }

        // =========================================================================
        // TEST 3 — Negative path: both fields empty
        // =========================================================================
        [Test]
        public async Task LoginFailsWithEmptyFields()
        {
            // FIX-04: Specific submit button selector
            await Page.Locator("button[type='submit']").ClickAsync();

            // FIX-03: Wait for validation elements to appear instead of sleeping
            await Page.Locator("#email-error").WaitForAsync();
            await Page.Locator("#password-error").WaitForAsync();

            var emailErrorVisible    = await Page.Locator("#email-error").IsVisibleAsync();
            var passwordErrorVisible = await Page.Locator("#password-error").IsVisibleAsync();

            // FIX-13: Modern Assert.That style with descriptive failure messages
            Assert.That(emailErrorVisible,    Is.True, "Email validation error should be visible.");
            Assert.That(passwordErrorVisible, Is.True, "Password validation error should be visible.");
        }

        // =========================================================================
        // TEST 4 — 'Remember Me' persists the session
        // =========================================================================
        [Test]
        public async Task RememberMeCheckboxWorks()
        {
            await Page.Locator("#email").FillAsync(email);
            await Page.Locator("#password").FillAsync(password);
            await Page.Locator("#remember-me").CheckAsync();

            // FIX-04: Specific submit button
            await Page.Locator("button[type='submit']").ClickAsync();
            await Page.WaitForURLAsync(baseUrl + "/dashboard");   // FIX-03

            // Open a fresh page in the same browser context to simulate a browser restart
            await Page.CloseAsync();
            var newPage = await Page.Context.NewPageAsync();
            await newPage.GotoAsync(baseUrl + "/dashboard");
            await newPage.WaitForLoadStateAsync(LoadState.NetworkIdle);   // FIX-03

            // FIX-13: Modern assertion style
            Assert.That(newPage.Url, Is.EqualTo(baseUrl + "/dashboard"),
                "With 'Remember Me' checked, re-opening the dashboard should not require re-login.");
        }

        // =========================================================================
        // TEST 5 — Logout flow
        // =========================================================================
        [Test]
        public async Task UserCanLogout()
        {
            await Page.Locator("#email").FillAsync(email);

            // FIX-09: Use the class-level 'password' field instead of re-hardcoding
            //         "Password123!" directly in this method.  If the password ever
            //         changes we only update one place.
            await Page.Locator("#password").FillAsync(password);

            // FIX-04: Specific submit button
            await Page.Locator("button[type='submit']").ClickAsync();
            await Page.WaitForURLAsync(baseUrl + "/dashboard");   // FIX-03

            await Page.Locator(".logout-button").ClickAsync();
            await Page.WaitForURLAsync(baseUrl + "/login");       // FIX-03

            // FIX-13: Modern assertion
            Assert.That(Page.Url, Is.EqualTo(baseUrl + "/login"),
                "After logout the user should be redirected to /login.");

            // Verify the session is truly invalidated — accessing /dashboard must
            // redirect back to /login, not show protected content.
            await Page.GotoAsync(baseUrl + "/dashboard");
            await Page.WaitForLoadStateAsync(LoadState.NetworkIdle);
            Assert.That(Page.Url, Is.EqualTo(baseUrl + "/login"),
                "Accessing /dashboard after logout should redirect to /login.");
        }

        // =========================================================================
        // TEST 6 — Password field must be masked
        // =========================================================================
        [Test]
        public async Task PasswordFieldShouldBeMasked()
        {
            // FIX-10: Use baseUrl consistently — the original test hardcoded the full
            //         URL here while other tests used the baseUrl field.  If the base
            //         URL ever changes only one place (the field) needs updating.
            //         Note: [SetUp] already navigates to baseUrl + "/login" so no
            //         extra navigation is needed here.

            var fieldType = await Page.Locator("#password").GetAttributeAsync("type");

            // FIX-13: Modern assertion
            Assert.That(fieldType, Is.EqualTo("password"),
                "The password input must have type='password' so the value is masked.");
        }

        // =========================================================================
        // TEST 7 — Forgot password link navigates correctly
        // =========================================================================
        [Test]
        public async Task ForgotPasswordLinkWorks()
        {
            // FIX-05: Page.Locator("a") matched *every* anchor tag on the page.
            //         Using "a[href*='forgot-password']" targets only the specific link
            //         we intend to click, making the test deterministic.
            await Page.Locator("a[href*='forgot-password']").ClickAsync();
            await Page.WaitForLoadStateAsync(LoadState.NetworkIdle);   // FIX-03

            // FIX-13: Modern assertion
            Assert.That(Page.Url, Does.Contain("forgot-password"),
                "Clicking 'Forgot Password' should navigate to the forgot-password page.");
        }

        // =========================================================================
        // TEST 8 — SQL injection must not bypass authentication
        // =========================================================================
        [Test]
        public async Task SqlInjectionAttemptShouldFail()
        {
            // FIX-12: Use descriptive names (emailLocator, not 'e')
            var emailLocator    = Page.Locator("#email");
            var passwordLocator = Page.Locator("#password");
            var submitButton    = Page.Locator("button[type='submit']");   // FIX-04

            await emailLocator.FillAsync("admin' OR '1'='1");
            await passwordLocator.FillAsync("admin' OR '1'='1");
            await submitButton.ClickAsync();

            await Page.WaitForLoadStateAsync(LoadState.NetworkIdle);   // FIX-03

            // FIX-10: Use baseUrl field for the expected URL
            Assert.That(Page.Url, Is.EqualTo(baseUrl + "/login"),
                "A SQL injection attempt must not result in a successful login.");

            // FIX-14: The original test only checked the URL.  We also verify that
            //         an error message is displayed to the user, confirming the server
            //         rejected the input rather than just silently staying on the page.
            var errorVisible = await Page.Locator(".error-message").IsVisibleAsync();
            Assert.That(errorVisible, Is.True,
                "An error message should be displayed when a SQL injection is attempted.");
        }
    }
}
